= allow to view product which stock are lower than certain amount // creat a methos that will always check if a stock is lower than certain number 

