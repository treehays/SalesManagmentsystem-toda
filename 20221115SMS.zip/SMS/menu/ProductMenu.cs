namespace SMS.menu
{
    public class ProductMenu
    {
        
    }
}