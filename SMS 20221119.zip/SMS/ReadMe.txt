= allow to view product which stock are lower than certain amount // creat a methos that will always check if a stock is lower than certain number 
#view product by categories
#add wallet to track  admin withdrawal and 
# view each attendant history
#purchasing multiple product same time
#allow customer to view list of product below certain price
#specify the attendants for particular transaction
#Admin for different branch

Kindly select one of the following options:
1. View Profile
2. Update profile
3. Register New Admin
4. Change Password
5. Add New Customers
6. View Customers
7. View all Attendants on Shift
8. Add New Attendants
9. View all Attendants
10. Perform inventory operations
11. Recall Order
12. View Order History
    {
        Kindly select one of the following options:
            1. View All Orders
            2. View Orders by date
            3. View Orders by attendant
            0. Go back to previous menu        
    }
0. Exit/ Log out




