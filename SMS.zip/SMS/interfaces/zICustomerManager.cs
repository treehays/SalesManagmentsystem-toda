/*
using SMS.model;

namespace SMS.interfaces
{
    public interface ICustomerManager
    {
        void CreateCustomer(string firstName, string lastName, string email, string phoneNumber, int pin, string address,double wallet);
        Customer GetCustomer(string customerId);
        void UpdateCustomer(string customerId, string firstName, string lastName, string phoneNumber);
        void DeleteCustomer(string customerId);
        Customer Login (string email,  int pin);
    }
}

*/