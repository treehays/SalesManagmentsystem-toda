
    public class WalletManager : IWalletManager
    {
        ITransactionManager _transactionManager = new TransactionManager();
        public decimal CalculateRemainingBalance()
        {
            throw new NotImplementedException();
        }
        public void CreateWallet()
        {
            throw new NotImplementedException();
        }

        public void GetTotalWalletTransaction()
        {
           
        }
    }