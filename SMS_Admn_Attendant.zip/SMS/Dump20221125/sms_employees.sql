-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: sms
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `employees`
--

DROP TABLE IF EXISTS `employees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employees` (
  `id` varchar(50) DEFAULT NULL,
  `firstname` varchar(100) DEFAULT NULL,
  `lastname` varchar(100) DEFAULT NULL,
  `department` varchar(100) DEFAULT NULL,
  `level` int DEFAULT NULL,
  `salary` decimal(10,0) DEFAULT NULL,
  `isdeleted` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employees`
--

LOCK TABLES `employees` WRITE;
/*!40000 ALTER TABLE `employees` DISABLE KEYS */;
INSERT INTO `employees` VALUES ('EMP001','Melody','Clark','HR',3,970000,0),('EMP002','Steve','Genovesi','FINANCE',6,40000,0),('EMP003','Tiffany','Kerr','HR',1,320000,0),('EMP004','Christine','Cramer','FINANCE',15,120000,0),('EMP005','Thomas','Noonan','TECH',13,250000,0),('EMP006','John','Laycock','FINANCE',12,120000,0),('EMP007','Kevin','Quist','TECH',1,1900000,0),('EMP008','Donald','Lucardi','HR',6,820000,0),('EMP009','Steve','Genovesi','FINANCE',3,400000,0),('EMP010','Tiffany','Kerr','FINANCE',5,400000,0),('EMP011','Clarissa','Perez','TECH',3,820000,0),('EMP012','Thomas','Noonan','HR',14,400000,0),('EMP013','Amy','Brown','FINANCE',11,2100000,0),('EMP014','John','Laycock','FINANCE',7,400000,0),('EMP015','Kevin','Quist','TECH',7,120000,0),('EMP016','Glen','Coleman','HR',11,730000,0),('EMP017','Steve','Genovesi','TECH',7,1900000,0),('EMP018','Julie','Chase','HR',15,250000,0),('EMP019','Gina','Palmertree','TECH',7,400000,0),('EMP020','Mary Kay','Hackley','TECH',3,970000,0),('EMP021','Linda','Atkins','HR',10,670000,0),('EMP022','Lance','Aldridge','FINANCE',14,1900000,0),('EMP023','Christine','Cramer','HR',5,250000,0),('EMP024','Katherine','Wise','HR',7,200000,0),('EMP025','Steve','Genovesi','FINANCE',12,320000,0),('EMP026','Julie','Chase','HR',9,730000,0),('EMP027','Gina','Palmertree','FINANCE',14,1450000,0),('EMP028','Mary Kay','Hackley','TECH',5,730000,0),('EMP029','Linda','Atkins','FINANCE',4,1450000,0),('EMP030','Lance','Aldridge','TECH',6,730000,0),('EMP031','Christine','Cramer','HR',10,70000,0),('EMP032','Katherine','Wise','FINANCE',13,70000,0),('EMP033','Donald','Lucardi','FINANCE',10,250000,0),('EMP034','Evan','Gill','TECH',13,70000,0),('EMP035','John','Laycock','HR',10,1900000,0),('EMP036','Melody','Clark','FINANCE',2,400000,0),('EMP037','Glen','Coleman','FINANCE',2,70000,0),('EMP038','Donald','Lucardi','TECH',5,820000,0),('EMP039','Atkins','Melody','HR',2,320000,0),('EMP040','Aldridge','Steve','TECH',14,670000,0),('EMP041','Cramer','Tiffany','HR',7,400000,0),('EMP042','Wise','Christine','TECH',2,120000,0),('EMP043','Lucardi','Thomas','TECH',11,970000,0),('EMP044','Gill','John','HR',6,70000,0),('EMP045','Laycock','Kevin','FINANCE',9,400000,0),('EMP046','Clark','Donald','FINANCE',7,2100000,0),('EMP047','Coleman','Steve','TECH',3,2100000,0),('EMP048','Lucardi','Tiffany','HR',12,2100000,0),('EMP049','Gina','Tiffany','FINANCE',2,2100000,0),('EMP050','Mary Kay','Tiffany','FINANCE',7,2100000,0);
/*!40000 ALTER TABLE `employees` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-25 22:25:00
