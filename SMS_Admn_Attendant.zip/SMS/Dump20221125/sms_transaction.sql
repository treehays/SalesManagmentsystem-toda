-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: sms
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `transaction`
--

DROP TABLE IF EXISTS `transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `transaction` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `receiptNo` varchar(100) NOT NULL,
  `Barcode` varchar(50) NOT NULL,
  `productname` varchar(255) NOT NULL,
  `price` decimal(15,2) NOT NULL,
  `quantity` int NOT NULL,
  `total` decimal(20,2) NOT NULL,
  `customerid` varchar(100) DEFAULT 'Customer',
  `cashtender` decimal(20,2) NOT NULL,
  `datetimes` varchar(100) NOT NULL,
  `withdraw` decimal(20,2) NOT NULL DEFAULT '0.00',
  `staffId` varchar(45) NOT NULL,
  PRIMARY KEY (`ID`,`receiptNo`),
  UNIQUE KEY `receiptNo` (`receiptNo`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transaction`
--

LOCK TABLES `transaction` WRITE;
/*!40000 ALTER TABLE `transaction` DISABLE KEYS */;
INSERT INTO `transaction` VALUES (13,'A837e43a3-37','111112','Rechargable Lamp ',10000.00,1,10000.00,'beyponce',2342334.00,'11/19/2022 10:55:56 PM',0.00,'APD310646	Attendant Name: adebisi'),(14,'A2662a7d0-8e','111112','Rechargable Lamp ',10000.00,12,120000.00,'sjifhkjd',28365728.00,'11/19/2022 10:57:06 PM',0.00,'APD310646	Attendant Name: adebisi'),(15,'Ab802b096-2f','111112','Rechargable Lamp ',10000.00,2,20000.00,'111112',344554.00,'11/19/2022 10:58:21 PM',0.00,'APD310646	Attendant Name: adebisi'),(16,'Ab2805dab-39','111112','Rechargable Lamp ',10000.00,10,100000.00,'1dsjsdkf',100010.00,'11/25/2022 8:54:30 AM',0.00,'AGJ553110Yusuf');
/*!40000 ALTER TABLE `transaction` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-25 22:25:01
