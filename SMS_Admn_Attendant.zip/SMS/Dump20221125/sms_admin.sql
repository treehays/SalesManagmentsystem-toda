-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: sms
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `admin` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `StaffId` varchar(25) NOT NULL,
  `FirstName` varchar(255) NOT NULL,
  `LastName` varchar(255) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `PhoneNumber` varchar(25) NOT NULL,
  `Pin` varchar(50) DEFAULT '0000',
  `Post` varchar(50) DEFAULT 'Attendant',
  PRIMARY KEY (`ID`,`StaffId`),
  UNIQUE KEY `StaffId` (`StaffId`),
  UNIQUE KEY `Email` (`Email`),
  UNIQUE KEY `PhoneNumber` (`PhoneNumber`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin`
--

LOCK TABLES `admin` WRITE;
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` VALUES (1,'ADU864054','ChangedFirst','ChangedLast','treehays@email.com','08066117783','pin',''),(5,'AUI988844','ChangedFirst','ChangedLast','sare','sdfg','pin','we'),(6,'AAY278748','Crescent','Smigo','smith273@gmail.com','09063431274','adeyemi','CTO'),(7,'AWG483212','Sam','adeyemi','samDel@gmail.com','0932343232','pin',''),(8,'AIJ778804','tree','yhre','sadfd','087372','pin','post'),(9,'AFG650163','kfsghf','dfisgsfid','fsidgk','fsidgk','pin','eofhubsd'),(10,'APN127792','khsjdfsd','','ggfdhdg','hgdsdf','fhgfdsgf','fgsgf'),(11,'ALD841804','Abdulsalam','Abdulmuiz','aoabdulsalam@gmail.com','09087643746','1234','Manager'),(12,'AXM215320','khalid','Arapaja','araraklid@gmail.com','08076235326','pin','Amin'),(13,'AFB119235','Ajibike','Abdulqayyumm','mafoloqayyum@gmail.com','0901223843','pin','CTO'),(14,'AXL162439','Agbajelola ','Mustaeenah','mustaeenaholadayo@gmail.com','0908735234','musty','President'),(15,'AMB379746','Testing','test','mad','09239843','1234','Manager'),(16,'AXF854472','firstName0','lastName0','email0','phoneNumber0','pin0','post0'),(17,'email1','phoneNumber1','AUW896268','firstName1','lastName1','pin1','post1'),(18,'AIE1033234','David','Mathirs','emaildavid@gmail.com','08065687548','wet','Massenger'),(19,'AYI676951','Adegboyega','Abdullah','adebullah@gmail.com','08034759832','YeaRMandela','Reseller'),(20,'ALK140329','Yasir','Muhammad','jablani@gmail.com','09034849334','treAp','Hawker'),(21,'AWM33577','Abdulsalam','Ahmad A','treehays@gmail.com','08064671994','TeAm','Developer'),(22,'ADE677899','reak','samuel','trewm@gmail.com','090983467','pres','Manger');
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-25 22:25:01
